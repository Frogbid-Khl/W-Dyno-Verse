<?php
$homepage = file_get_contents('https://frogbid.com/chubb/index.php');

